package com.org;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.Date;
import java.util.Scanner;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.google.gson.JsonObject;


@WebServlet("/MyServlet")
public class MyServlet extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		String city=request.getParameter("city");
//		System.out.println(city);
//		doGet(request,response);
		
		//API setup
		String apikey="9e551bcbd202b1f1a282c761b9377319";
		
		//Get the city from that input
		String city=request.getParameter("city");	
		
		//Create a URL for the OpenWeatherMap API request
		String apiURL = "https://api.openweathermap.org/data/2.5/weather?q=" + city + "&appid=" + apikey;
		
		//API integration 
		URL url=new URL(apiURL);
		
		//URL Connection
		HttpURLConnection connection=(HttpURLConnection) url.openConnection();
		connection.setRequestMethod("GET");
		
		//(Reading the data from network)The Data which is getting that should get read, so for that we used InputSteam class
		InputStream inputstream=connection.getInputStream();
		
		//For reading the data we use reader class form InputStream
		InputStreamReader reader=new InputStreamReader(inputstream);
		
		//Want to store in String;But we can't use string it is immutable-we can't change it ,so to over come it we use SringBuilder
		StringBuilder responseContent=new StringBuilder();
		
		//From taking input from reader we will create scanner object
		Scanner scanner=new Scanner(reader);      //Why not System.in because that it will take the data from console 
		
		while(scanner.hasNext()) {
			//hasNext=>It will scan till last line
			responseContent.append(scanner.nextLine());
			//responeContent=>To store data in String ,now 1 item is read , for next line use nextLine
		}
		
		scanner.close();
//		System.out.println(responseContent);
		
		//Type Casting=passing the data into json
		Gson gson=new Gson();
		JsonObject jsonObject=gson.fromJson(responseContent.toString(),JsonObject.class);
		System.out.println(jsonObject);
		
		//Date and Time
		long dateTimestamp=jsonObject.get("dt").getAsLong()*1000;
		
		//Object Type Casting
		String date=new Date(dateTimestamp).toString();
		
		//Temperature(getASDOuble=>Type Conversion)
//		double temperatureKelvin=jsonObject.getAsJsonObject("main").get("temp").getAsDouble();
//		int temperatureCelsium = (int) (temperatureKelvin - 273.15);
//		double temperatureCelsius = jsonObject.getAsJsonObject("main").get("temp").getAsDouble();
//		int temperature = (int) temperatureCelsius;
		double temperatureKelvin = jsonObject.getAsJsonObject("main").get("temp").getAsDouble();
        int temperatureCelsius = (int) (temperatureKelvin - 273.15);
		
		//Humidity
		int humidity=jsonObject.getAsJsonObject("main").get("humidity").getAsInt();
		
		//Wind and Speed
		double speed=jsonObject.getAsJsonObject("wind").get("speed").getAsDouble();
		double speedKMH = speed * 3.6;

		//weathercondition
		String weatherCondition=jsonObject.getAsJsonArray("weather").get(0).getAsJsonObject().get("main").getAsString();
		
		// Set icon URL based on condition
        String iconURL = "";
        switch (weatherCondition.toLowerCase()) {
            case "clear": iconURL = "https://openweathermap.org/img/wn/01d.png"; break;
            case "clouds": iconURL = "https://openweathermap.org/img/wn/03d.png"; break;
            case "rain": iconURL = "https://openweathermap.org/img/wn/09d.png"; break;
            case "drizzle": iconURL = "https://openweathermap.org/img/wn/10d.png"; break;
            case "thunderstorm": iconURL = "https://openweathermap.org/img/wn/11d.png"; break;
            case "snow": iconURL = "https://openweathermap.org/img/wn/13d.png"; break;
            case "mist": iconURL = "https://openweathermap.org/img/wn/50d.png"; break;
            default: iconURL = "https://openweathermap.org/img/wn/01d.png";
        }
        
        // Set attributes
		request.setAttribute("temperature",  temperatureCelsius );
		request.setAttribute("city", city);
		request.setAttribute("date", date);
		request.setAttribute("humidity", humidity);
		request.setAttribute("speed", speed);
		request.setAttribute("speedKMH", speedKMH);
		request.setAttribute("weatherCondition", weatherCondition);
		request.setAttribute("iconURL", "https://openweathermap.org/img/wn/03d@2x.png");

//		request.setAttribute("weatherData", responseContent.toString());

		
		connection.disconnect();
		
		//Forward the request to weather jsp page for rendering
		request.getRequestDispatcher("index.jsp").forward(request, response);
		
		
		
		
	}

}
